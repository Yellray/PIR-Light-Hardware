*PADS-LIBRARY-PART-TYPES-V9*

DTA114EUAHE3-TP SOT65P228X120-3N I TRX 7 1 0 0 0
TIMESTAMP 2026.06.23.22.53.18
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" MCC
"Manufacturer_Part_Number" DTA114EUAHE3-TP
"Description" DIGITAL TRANSISTOR PNP 50V 0.1A SOT-323
"Datasheet Link" https://www.mccsemi.com/pdf/Products/DTA114EUAHE3(SOT-323).pdf
"Geometry.Height" 1.2mm
GATE 1 3 0
DTA114EUAHE3-TP
1 0 U IN
2 0 U GND
3 0 U OUT

*END*
*REMARK* SamacSys ECAD Model
18018048/1585334/2.50/3/2/Transistor
