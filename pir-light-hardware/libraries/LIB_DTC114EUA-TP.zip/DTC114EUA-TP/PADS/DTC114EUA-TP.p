*PADS-LIBRARY-PART-TYPES-V9*

DTC114EUA-TP SOT65P228X120-3N I TRX 7 1 0 0 0
TIMESTAMP 2026.06.23.22.54.05
"Mouser Part Number" 833-DTC114EUA-TP
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Micro-Commercial-Components-MCC/DTC114EUA-TP?qs=SdqRYZZ9IxAUg6qX6TcetA%3D%3D
"Manufacturer_Name" MCC
"Manufacturer_Part_Number" DTC114EUA-TP
"Description" Pre-Biased Transistors
"Datasheet Link" https://www.mccsemi.com/pdf/Products/DTC114EUA(SOT-323).pdf
"Geometry.Height" 1.2mm
GATE 1 3 0
DTC114EUA-TP
1 0 U IN
2 0 U GND
3 0 U OUT

*END*
*REMARK* SamacSys ECAD Model
771499/1585334/2.50/3/2/Transistor
